#ifndef _DMA_H
#define _DMA_H
#include <stdint.h>

volatile uint32_t *inst_ptr;
volatile uint32_t inst_addr = 0x36000000;
#endif